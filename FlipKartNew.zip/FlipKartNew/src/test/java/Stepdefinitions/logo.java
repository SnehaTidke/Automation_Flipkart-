package Stepdefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Then;

public class logo {
	WebDriver driver;
	 @Then("Flipcart logo is visible at top right corner")
	    public void Flipcart_logo_is_visible_at_top_right_corner() {
	        driver= new ChromeDriver();
	        driver.get("https://www.flipkart.com/");
	        driver.findElement(By.xpath("//button[@class=\"_2KpZ6l _2doB4z\"]")).click();
	        driver.findElement(By.xpath("//div[@class='_3qX0zy']")).isDisplayed();
	    }

	 

	    
}
