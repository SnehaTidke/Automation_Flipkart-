package Stepdefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class searchh {
	WebDriver driver;
	@Given("User is on the hompage")
	public void user_is_on_the_hompage() throws InterruptedException {
		 System.setProperty("webdriver.chrome.driver","C:\\Eclipse Workspace\\FlipKartNew\\src\\test\\resources\\Drivers\\chromedriver.exe");
	        driver = new ChromeDriver();
	        driver.navigate().to("https://flipkart.com/");
	        driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	        Thread.sleep(3000);
	        }
	

	@When("user click on searchbar")
	public void user_click_on_searchbar() {
		driver.findElement(By.xpath("//button[@class=\"_2KpZ6l _2doB4z\"]")).click();
		WebElement searchh= driver.findElement(By.xpath("//input[@class=\"_3704LK\"]"));
		searchh.sendKeys("mobile");
		driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[1]/div[1]/div[2]/div[2]/form/div/button")).click();
//		driver.findElement(By.xpath(""))
	    
	}

	@Then("user will get popular result")
	public void user_will_get_popular_result() {
		driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[1]/div/div[1]/div/div/section/div[3]/div/a")).isDisplayed();
	    
	}



}
