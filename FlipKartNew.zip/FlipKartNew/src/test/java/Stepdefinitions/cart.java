package Stepdefinitions;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Then;
public class cart {
	WebDriver driver;
	 @Then("cart logo is visible")
	    public void cart_logo_is_visible() {
	        System.setProperty("webdriver.chrome.driver","C:\\Eclipse Workspace\\FlipKartNew\\src\\test\\resources\\Drivers\\chromedriver.exe"); 
	        driver= new ChromeDriver();
	        driver.get("https://www.flipkart.com/");
//	        button to click cross of login
	        driver.findElement(By.xpath("//button[@class=\"_2KpZ6l _2doB4z\"]")).click();
	        driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[1]/div[1]/div[2]/div[6]/div/div/a")).click();
	        driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	        //driver.findElement(By.xpath("//*[@id=\"container\"]")).click();
	        //driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	    }

}
