package Stepdefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class title {
	WebDriver driver;
    @Given("user open google")
    public void user_open_google() {
         System.setProperty("webdriver.chrome.driver","C:\\Eclipse Workspace\\FlipKartNew\\src\\test\\resources\\Drivers\\chromedriver.exe"); 
          driver = new ChromeDriver();
            driver.get("https://google.com");
            driver.findElement(By.xpath("//*[@id=\"L2AGLb\"]")).click();
    }

 

    @When("Type url of Flipcart")
    public void type_url_of_flipcart() {
        driver.findElement(By.name("q")).sendKeys("Flipcart");
//         driver.manage().timeouts().pageLoadTimeout(70, TimeUnit.SECONDS);
         driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
             driver.findElement(By.name("q")).sendKeys(Keys.ENTER);
             driver.manage().timeouts().pageLoadTimeout(70, TimeUnit.SECONDS);
             driver.findElement(By.xpath("//div[@class=\"TbwUpd NJjxre\"]")).click();
             driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);   
    }

 

    @Then("user is on Flipcart website")
    public void user_is_on_flipcart_website() throws InterruptedException {
        String reg=driver.getTitle();
        String str2="Online Shopping Site for Mobiles, Electronics, Furniture, Grocery, Lifestyle, Books & More. Best Offers!";
        if (reg.equals(str2)) {
            System.out.println("Login page for flipkart title Verified");
        }
        else
        {
            driver.navigate().back();
        }
           //driver.manage().timeouts().pageLoadTimeout(70, TimeUnit.SECONDS);
          Thread.sleep(3000);
          driver.close();
    }
}
